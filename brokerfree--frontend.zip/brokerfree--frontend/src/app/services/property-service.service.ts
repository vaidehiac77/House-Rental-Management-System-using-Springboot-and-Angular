import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Property } from '../model/property';
import {HttpClient}from '@angular/common/http'
let pService = "http://localhost:8080/property/";
@Injectable({
  providedIn: 'root'
})
export class PropertyServiceService {
  
  constructor( private _http: HttpClient){}

  public addPropertyfromRemote(property : Property):Observable<any>
  {
  return  this._http.post<any>("http://localhost:7070/addProperty",property);
  }
  public getAllProperty():Observable<any>
  {
  return  this._http.get("http://localhost:7070/viewProperty");
}

public deleteProperty(pid:number) {
  return this._http.delete("http://localhost:7070/deleteProperty/"+pid);
}

public editProperty(pid: number,property:Property):Observable<any>{
  return this._http.put<any>("http://localhost:7070/updateProperty/"+pid,property);
}
}
