export class Tenant {

    tid? : number;

	tname?: string
	
    temail? :string;
	
    tcontact? :string;
	
    tpassword?: string;

    constructor()
    {}
}
