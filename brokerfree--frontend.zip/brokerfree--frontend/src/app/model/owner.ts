export class Owner {
    oid? : number;
	oname ?: string;
	oemail ? : string;
	ocontact? : string;
    opassword ?: string;
    
   constructor()
    {
       

    }
}
